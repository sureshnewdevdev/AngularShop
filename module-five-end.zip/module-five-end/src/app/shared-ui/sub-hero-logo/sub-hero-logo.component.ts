import { Component } from '@angular/core';

@Component({
  standalone: true,
  imports: [],
  selector: 'app-sub-hero-logo',
  templateUrl: './sub-hero-logo.component.html',
  styleUrls: ['./sub-hero-logo.component.css']
})
export class SubHeroLogoComponent {

}
