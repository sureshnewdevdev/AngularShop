export interface ContactForm {
  fullName?: string;
  email?: string;
  phone?: string;
  comment?: string;
}
